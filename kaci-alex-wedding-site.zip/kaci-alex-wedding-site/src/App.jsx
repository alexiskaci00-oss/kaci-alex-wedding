
export default function App() {
  const weddingDate = new Date('2026-08-22T17:00:00')
  const now = new Date()
  const difference = weddingDate - now
  const days = Math.max(Math.floor(difference / (1000 * 60 * 60 * 24)), 0)

  return (
    <div className="site">
      <audio autoPlay loop controls className="music-player">
        <source src="https://cdn.pixabay.com/download/audio/2022/03/15/audio_c8f6bdf0b1.mp3?filename=wedding-background-piano-110624.mp3" type="audio/mp3" />
      </audio>

      <section className="hero">
        <div className="overlay"></div>

        <div className="hero-content">
          <div className="envelope">
            <div className="envelope-top"></div>

            <div className="invite-card">
              <img src="/invite.jpg" alt="Wedding Invite" />
            </div>

            <div className="seal">K&A</div>
          </div>

          <div className="intro">
            <p className="small-text">Together with their families</p>
            <h1>Kaci & Alex</h1>
            <div className="divider"></div>
            <p className="date-text">
              Saturday • August 22, 2026 • 5 PM
            </p>
          </div>

          <a href="#details" className="main-button">
            Tap To Continue
          </a>
        </div>
      </section>

      <section className="countdown">
        <p className="small-text">Countdown To Forever</p>
        <h2>{days}</h2>
        <p className="date-text">Days Until We Say I Do</p>
      </section>

      <section id="details" className="details">
        <div className="details-card">
          <h2>The Finer Details</h2>

          <img src="/details.jpg" alt="Wedding Details" />

          <div className="detail-block">
            <h3>What To Wear</h3>
            <p>Semi-formal / cocktail attire. Think elegant yet comfortable.</p>
          </div>

          <div className="detail-block">
            <h3>Age Restriction</h3>
            <p>We kindly request a child-free celebration.</p>
          </div>

          <div className="detail-block">
            <h3>Food & Drinks</h3>
            <p>BYO alcohol celebration. Food provided for guests who RSVP.</p>
          </div>

          <div className="detail-block">
            <h3>RSVP</h3>
            <p>Please RSVP with Kaci by June 10, 2026.</p>
          </div>
        </div>
      </section>

      <section className="rsvp">
        <h2>RSVP</h2>
        <p>We can’t wait to celebrate with you.</p>

        <a
          className="main-button"
          href="https://forms.gle/YOUR_GOOGLE_FORM_LINK"
          target="_blank"
        >
          RSVP Here
        </a>
      </section>

      <section className="directions">
        <h2>Directions</h2>

        <p className="date-text">
          21 New Hope Church Road<br />
          Chatsworth, GA 30705
        </p>

        <a
          className="secondary-button"
          href="https://maps.google.com/?q=21+New+Hope+Church+Road+Chatsworth+GA+30705"
          target="_blank"
        >
          Open In Maps
        </a>
      </section>

      <section className="gallery">
        <h2>Our Story</h2>

        <div className="gallery-grid">
          <img src="https://images.unsplash.com/photo-1522673607200-164d1b6ce486?q=80&w=1200&auto=format&fit=crop" />
          <img src="https://images.unsplash.com/photo-1511285560929-80b456fea0bc?q=80&w=1200&auto=format&fit=crop" />
          <img src="https://images.unsplash.com/photo-1529636798458-92182e662485?q=80&w=1200&auto=format&fit=crop" />
        </div>
      </section>

      <footer>
        <h2>We Can’t Wait To Celebrate With You</h2>
        <p>Kaci & Alex • August 22, 2026</p>
      </footer>
    </div>
  )
}
